#! /bin/bash
# Actualizado por TM 1-Feb-2021
#
dt=`date +20%y%m%d`
ti=`date +%H%M%d`
hs=`hostname`
echo
echo Check Netbackup en `hostname`
echo
#
/usr/openv/netbackup/bin/bpclntcmd -hn dcl-nb5240-m
echo
/usr/openv/netbackup/bin/bpclntcmd -hn `hostname`
echo
echo "***"
echo "**"
echo "*"

