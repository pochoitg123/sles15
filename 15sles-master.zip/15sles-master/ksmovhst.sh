#! /bin/bash
#				Actualizado por TM 16-Dic-2020
#
dt=`date +20%y%m%d`
ti=`date +%H%M%d`
hs=`hostname`
echo
echo Mueve key a varios hosts
# Corregir lista de hosts
kmov.sh es4desnw
kmov.sh es4qasnw
kmov.sh es4prdnw
#

