#! /bin/bash
#
#
dt=`date +20%y%m%d`
ti=`date +%H%M%d`
hs=`hostname`
writein="clamav_$hs-$dt-$ti.log"
echo
echo fix_clamav.sh en `hostname`
zypper install -y clamav
zypper install -y clamsap
touch /var/log/freshclam.log
chmod 600 /var/log/freshclam.log
freshclam
clamscan ~
ps -ef | grep clam
systemctl start clamd
systemctl enable clamd

cp /etc/clamd.conf /etc/clamd.conf.$dt$ti
sed -i "s%3310%44410%g" "/etc/clamd.conf"

mkdir /home/appmon/log
chmod 777 /home/appmon/log
cp /root/15sles/clamscan.sh /root/bin
chmod +x /root/bin/clamscan.sh
echo "Use comando crontab -e"
echo "Luego agregue 5 0 * * * /root/bin/clamscan.sh"
echo verifique con comando crontab -l
echo "***"
echo "**"
echo "*"
