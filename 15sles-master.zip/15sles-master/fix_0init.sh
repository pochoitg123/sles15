#!/bin/bash
# fix_0init.sh
#
dt=`date +20%y%m%d`
ti=`date +%H%M%S`
hs=`hostname`
writein="/root/log/fix_0init.log"
#
SUSEConnect -p sle-module-desktop-applications/15.3/x86_64
SUSEConnect -p sle-module-development-tools/15.3/x86_64
SUSEConnect -p sle-module-legacy/15.3/x86_64
SUSEConnect -p sle-module-web-scripting/15.3/x86_64
#
zypper install git
mkdir /root/log
echo "ejecutando fix_0init.sh en $hs $dt $ti"
echo "# $dt $ti" >> /etc/init.d/boot.local
mv /etc/init.d/boot.local /etc/init.d/boot.local-$dt-$ti
chmod +x /root/15sles/boot_local.sh
cp /root/15sles/boot_local.sh /etc/init.d/boot.local
/root/15sles/chk_sysctlresp.sh
/root/15sles/fix_deprecated.sh
/root/15sles/fix_appmon.sh
visudo
/root/15sles/fix_sublime.sh
/root/15sles/fix_xrdp.sh
#

