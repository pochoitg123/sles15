#! /bin/bash
#
# SAP VARIOS Params
#
dt=`date +20%y%m%d`
ti=`date +%H%M%d`
hs=`hostname`
writein="fix_varios.txt"
function conparam1 {
	paramv=`sysctl -a | grep $1 | awk '{print $3}'`
	if [ $paramv -ge $2 ]
	then
		echo $1 "=" $paramv ">=" $2
	else
		echo $1 "=" $2
		echo $1 "=" $2 >> $writein
	fi
	echo
}
#
function conparam2 {
	paramv1=`sysctl -a | grep $1 | awk '{print $3}'`
	paramv2=`sysctl -a | grep $1 | awk '{print $4}'`
	if [ $paramv1 -ge $2 ]
	then
		if [ $paramv2 -ge $3 ]
		then
			echo $1 "=" $paramv1 ">=" $2 $paramv2 ">=" $3
		else
			echo $1 "=" $paramv1 $3   
			echo $1 "=" $paramv1 $3 >> $writein
		fi
	else
		if [ $paramv2 -ge $3 ]
                then         
                        echo $1 "=" $2 $paramv2 
                        echo $1 "=" $2 $paramv2 >> f$writein
                else
                        echo $1 "=" $2 $3  
                        echo $1 "=" $2 $3 >> f$writein 
                fi
	fi
	echo
}
#
function conparam3 {
	paramv1=`sysctl -a | grep $1 | awk '{print $3}'`
	paramv2=`sysctl -a | grep $1 | awk '{print $4}'`
	paramv3=`sysctl -a | grep $1 | awk '{print $5}'`
	if [ $paramv1 -ge $2 ]
	then
		if [ $paramv2 -ge $3 ]
		then
			if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $paramv1 ">=" $2 $paramv2 ">=" $3 $paramv3 ">=" $4
			else
				echo $1 "=" $paramv1 $paramv2 $4
				echo $1 "=" $paramv1 $paramv2 $4 >> $writein
			fi
		else
			if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $paramv1 $3 $paramv3
				echo $1 "=" $paramv1 $3 $paramv3 >> $writein
			else
				echo $1 "=" $paramv1 $3 $4
				echo $1 "=" $paramv1 $3 $4 >> $writein
			fi  
		fi
	else
		if [ $paramv2 -ge $3 ]
        then  
        	if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $2 $paramv2 $paramv3
				echo $1 "=" $2 $paramv2 $paramv3 >> $writein
			else
				echo $1 "=" $2 $paramv2 $4
				echo $1 "=" $2 $paramv2 $4 >> $writein
			fi         
        else
        	if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $2 $3 $paramv3
				echo $1 "=" $2 $3 $paramv3 >> $writein
			else
				echo $1 "=" $2 $3 $4
				echo $1 "=" $2 $3 $4 >> $writein
			fi  
        fi
	fi
	echo
}
#
echo Analisis Varios en $hs $dt
echo "# " > $writein
echo "# fix_varios" $dt $ti >> $writein
# Kernel
paramn="fs.file-max"
parame=6815744
conparam1 $paramn $parame
#
paramn="fs.aio-max-nr"
parame=1048576
conparam1 $paramn $parame
#
#paramn="net.ipv4.ip_local_port_range"
#parame1=9000
#parame2=165500
#conparam2 $paramn $parame1 $parame2
#
paramn="net.core.rmem_default"
parame=16777216
conparam1 $paramn $parame
#
paramn="net.core.rmem_max"
parame=16777216
conparam1 $paramn $parame
#
paramn="net.core.wmem_default"
parame=16777216
conparam1 $paramn $parame
#
paramn="net.core.wmem_max"
parame=16777216
conparam1 $paramn $parame
#
#paramn="vm.pagecache_limit_mb"
#parame=2048
#conparam1 $paramn $parame
#
paramn="net.core.netdev_max_backlog"
parame=30000
conparam1 $paramn $parame
#
#
# Additional Kernel
#
paramn="vm.hugetlb_shm_group"
parame=501
conparam1 $paramn $parame
#
echo "# chk_varios" >> $writein
echo "#" >> $writein
#
var1=$(grep 'fix_varios' /etc/sysctl.conf)
if [ -z "$var1" ]
then
   cat $writein >> /etc/sysctl.conf
fi
#
systemctl enable sysstat
systemctl start sysstat
systemctl status sysstat
#
