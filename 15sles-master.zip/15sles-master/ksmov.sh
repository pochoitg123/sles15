#! /bin/bash
#				Actualizado por TM 16-Dic-2020
#
dt=`date +20%y%m%d`
ti=`date +%H%M%d`
hs=`hostname`
echo
echo Mueve key de `hostname` a $1
#
if [ -z $1 ]
then
	echo Falta host de destino
else
	ssh-copy-id root@$1
fi
echo
echo "***"
echo "**"
echo "*"
