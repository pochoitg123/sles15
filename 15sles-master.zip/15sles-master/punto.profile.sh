#! /bin/bash
#				Actualizado por TM 16-Dic-2020
#
dt=`date +20%y%m%d`
ti=`date +%H%M%d`
hs=`hostname`
echo
echo bienvenido a $hostname hoy $dt a las $ti
cat /etc/issue
PATH=$PATH:/root/15sles:/root/15iperf3
export PATH
echo $PATH
#
echo "***"
echo "**"
echo "*"
