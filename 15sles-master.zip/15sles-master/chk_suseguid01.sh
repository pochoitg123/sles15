# !/bin/bash
#
# "SLES Memory Tuning and Optimization"
#
dt=`date +20%y%m%d`
ti=`date +%H%M%d`
hs=`hostname`
echo
echo chk_suseguid01.sh en `hostname`
echo
function leeparam1 {
	paramv=`sysctl -a | grep -w $1 | awk '{print $3}'`
	echo $1 "=" $paramv
	if [ $paramv -ge $2 ]
	then
		echo $1 "=" $paramv ">=" $2
	else
		echo $1 "=" $2 "***"
	fi
	echo
}
#
function leeparam2 {
	paramv1=`sysctl -a | grep $1 | awk '{print $3}'`
	paramv2=`sysctl -a | grep $1 | awk '{print $4}'`
	echo $1 "=" $paramv1 $paramv2
	if [ $paramv1 -ge $2 ]
	then
		if [ $paramv2 -ge $3 ]
		then
			echo $1 "=" $paramv1 ">=" $2 $paramv2 ">=" $3
		else
			echo $1 "=" $paramv1 $3 "***"  
		fi
	else
		if [ $paramv2 -ge $3 ]
                then         
                        echo $1 "=" $2 $paramv2 "***"
                else
                        echo $1 "=" $2 $3 "***" 
                fi
	fi
	echo
}
#
function leeparam3 {
	paramv1=`sysctl -a | grep $1 | awk '{print $3}'`
	paramv2=`sysctl -a | grep $1 | awk '{print $4}'`
	paramv3=`sysctl -a | grep $1 | awk '{print $5}'`
	echo $1 "=" $paramv1 $paramv2 $paramv3
	if [ $paramv1 -ge $2 ]
	then
		if [ $paramv2 -ge $3 ]
		then
			if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $paramv1 ">=" $2 $paramv2 ">=" $3 $paramv3 ">=" $4
			else
				echo $1 "=" $paramv1 $paramv2 $4 "***"
			fi
		else
			if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $paramv1 $3 $paramv3 "***"
			else
				echo $1 "=" $paramv1 $3 $4 "***"
			fi  
		fi
	else
		if [ $paramv2 -ge $3 ]
        then  
        	if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $2 $paramv2 $paramv3 "***"
			else
				echo $1 "=" $2 $paramv2 $4 "***"
			fi         
        else
        	if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $2 $3 $paramv3 "***"
			else
				echo $1 "=" $2 $3 $4 "***"
			fi  
        fi
	fi
	echo
}
#
function leefile1 {
	filev=`cat $1`
	echo $1 "=" $filev
	if [ $filev -ge $2 ]
	then
		echo $1 "=" $filev ">=" $2
	else
		echo $1 "=" $2 "***"
	fi
	echo
}
#
echo
echo Check suseguid01 en `hostname`
echo "SLES Memory Tuning and Optimization"
echo
echo "cat /sys/kernel/mm/transparent_hugepage/enabled"
cat /sys/kernel/mm/transparent_hugepage/enabled
filev3=`cat /sys/kernel/mm/transparent_hugepage/enabled | awk '{print $3}'`
filevx="[never]"
if [ $filevx = $filev3 ]
then
	echo Esta OK para Hana
else
	echo Parametro debe quedar en "[never]"
fi
echo
# 
paramn="vm.nr_hugepages"
parame=128
leeparam1 $paramn $parame
#
paramn="vm.swappiness"
parame=25
leeparam1 $paramn $parame
#
paramn="vm.vfs_cache_pressure"
parame=50
leeparam1 $paramn $parame
#
echo Kernel Samepage Merging = 1
paramn="/sys/kernel/mm/ksm/run"
parame=1
leefile1 $paramn $parame
#
echo Memory Overcommit = 0 Kernel checks before grants memory
echo Memory Overcommit = 1 Kernel asumes that has memory and grants memory
echo Memory Overcommit = 2 Kernel overcommit - deny memory if it does not have
paramn="vm.overcommit_memory"
parame=0
leeparam1 $paramn $parame
#
echo vm.overcommit_ratio = 50 allocate 50% more than RAM+SWAP
paramn="vm.overcommit_ratio"
parame=20
leeparam1 $paramn $parame  
#
echo Free mechanism to drop used memory when swapping. It would be desirable to run “sync” command first before freeing up pagecache , dentries and inodes”
echo “To free pagecache:                                  1”
echo “To free dentries and inodes:                        2”
echo “To free pagecache, dentries and inodes:             3”
paramn="vm.drop_caches"
parame=1
leeparam1 $paramn $parame
#
echo
echo "SLES Disk I/O & Storage Tuning Optimization"
echo
echo If there are performance issues observed with write performance on systems with large memory 128GB+, change the memory percentage settings for dirty_ratio =10 and dirty_background_ratio = 5 as documented in TID# 7010287.”
echo
paramn="vm.dirty_ratio"
parame=10
leeparam1 $paramn $parame
#
paramn="vm.dirty_background_ratio"
parame=5
leeparam1 $paramn $parame
#
echo CFQ is the default scheduler, NOOP is SSD oriented and Deadline is multipurpose intelligent scheduler.
echo elevator=noop or elevator=deadline
cat /sys/block/sd*/queue/scheduler
echo
echo Default 128 or 512, 1024 or 2048 with fast disks and high is 8192. High value could mean to down nr_requests from 128 to 1.
echo “/sys/block/device-name/queue/read_ahead_kb 1024”
cat /sys/block/sd*/queue/read_ahead_kb
echo
echo “/sys/block/device-name/queue/nr_requests 128”
cat /sys/block/sd*/queue/nr_requests
echo
echo “File System journal mode on SLES is data=ordered which ensures data is written to disk before it is written to journal, improve performance mounting the filesystem with data=writeback, barrier=0 would improve filesystem performance at cost reliability. 
echo “/dev/sdc   /SAP  ext3   acl,user_xattr, data=writeback  barrier=0    1   1”
cat /etc/fstab
echo
echo Configure Kdump For server with large amount of RAM 512 GB – 1 TB and above, with sufficient disk space available to collect memory dump a reasonable value for KDUMP_DUMPLEVEL in /etc/sysconfig/kdump file would be 15.
cat /etc/sysconfig/kdump | grep KDUMP_DUMPLEVEL
echo
echo "***"
echo "**"
echo "*"

