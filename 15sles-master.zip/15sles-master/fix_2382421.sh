#! /bin/bash
#
# 2382421 - Optimizing the Network Configuration on HANA and OS Level
#
dt=`date +20%y%m%d`
ti=`date +%H%M%d`
hs=`hostname`
writein="fix_2382421.txt"
function conparam1 {
	paramv=`sysctl -a | grep $1 | awk '{print $3}'`
	if [ $paramv -ge $2 ]
	then
		echo $1 "=" $paramv ">=" $2
	else
		echo $1 "=" $2
		echo $1 "=" $2 >> $writein
	fi
	echo
}
#
function conparam2 {
	paramv1=`sysctl -a | grep $1 | awk '{print $3}'`
	paramv2=`sysctl -a | grep $1 | awk '{print $4}'`
	if [ $paramv1 -ge $2 ]
	then
		if [ $paramv2 -ge $3 ]
		then
			echo $1 "=" $paramv1 ">=" $2 $paramv2 ">=" $3
		else
			echo $1 "=" $paramv1 $3   
			echo $1 "=" $paramv1 $3 >> $writein
		fi
	else
		if [ $paramv2 -ge $3 ]
                then         
                        echo $1 "=" $2 $paramv2 
                        echo $1 "=" $2 $paramv2 >> f$writein
                else
                        echo $1 "=" $2 $3  
                        echo $1 "=" $2 $3 >> f$writein 
                fi
	fi
	echo
}
#
function conparam3 {
	paramv1=`sysctl -a | grep $1 | awk '{print $3}'`
	paramv2=`sysctl -a | grep $1 | awk '{print $4}'`
	paramv3=`sysctl -a | grep $1 | awk '{print $5}'`
	if [ $paramv1 -ge $2 ]
	then
		if [ $paramv2 -ge $3 ]
		then
			if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $paramv1 ">=" $2 $paramv2 ">=" $3 $paramv3 ">=" $4
			else
				echo $1 "=" $paramv1 $paramv2 $4
				echo $1 "=" $paramv1 $paramv2 $4 >> $writein
			fi
		else
			if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $paramv1 $3 $paramv3
				echo $1 "=" $paramv1 $3 $paramv3 >> $writein
			else
				echo $1 "=" $paramv1 $3 $4
				echo $1 "=" $paramv1 $3 $4 >> $writein
			fi  
		fi
	else
		if [ $paramv2 -ge $3 ]
        then  
        	if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $2 $paramv2 $paramv3
				echo $1 "=" $2 $paramv2 $paramv3 >> $writein
			else
				echo $1 "=" $2 $paramv2 $4
				echo $1 "=" $2 $paramv2 $4 >> $writein
			fi         
        else
        	if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $2 $3 $paramv3
				echo $1 "=" $2 $3 $paramv3 >> $writein
			else
				echo $1 "=" $2 $3 $4
				echo $1 "=" $2 $3 $4 >> $writein
			fi  
        fi
	fi
	echo
}
#
echo
echo Fix SAP2382421 en `hostname`
echo "SAP NOTE 2382421 - Optimizing the Network Configuration on HANA and OS Level"
echo
echo "#" > $writein
echo "#" $writein $dt $ti >> $writein
paramn="net.core.somaxconn"
parame=4096
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_max_syn_backlog" 
parame=8192
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_tw_reuse"
parame=1
conparam1 $paramn $parame
#
#paramn="net.ipv4.tcp_tw_recycle"
#parame=1
#conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_timestamps"
parame=1
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_slow_start_after_idle"
parame=0
conparam1 $paramn $parame
#
paramn="net.core.rmem_max"
parame=16777216
conparam1 $paramn $parame
#
paramn="net.core.wmem_max"
parame=16777216
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_rmem"
parame1=65536
parame2=262144
parame3=16777216
conparam3 $paramn $parame1 $parame2 $parame3
#
paramn="net.ipv4.tcp_wmem"
parame1=65536
parame2=262144
parame3=16777216
conparam3 $paramn $parame1 $parame2 $parame3
#
paramn="net.ipv4.tcp_window_scaling"
parame=1
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_syn_retries"
parame=8
conparam1 $paramn $parame
#
paramn="vm.dirty_ratio"
parame=10
conparam1 $paramn $parame
#
paramn="vm.dirty_background_ratio"
parame=5
conparam1 $paramn $parame
#
echo "#" $writein >> $writein
echo "#" >> $writein
var1=$(grep 'fix_2382421' /etc/sysctl.conf)
if [ -z "$var1" ]
then
   cat $writein >> /etc/sysctl.conf
fi
echo "***"
echo "**"
echo "*"

