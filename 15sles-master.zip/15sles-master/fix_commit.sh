#! /bin/bash
#
# SOLO PARA USO de TMartinez
dt=`date +20%y%m%d`
ti=`date +%H%M%d`
hs=`hostname`
writein="fix_commit-$hs-$dt-$ti.log"
echo
echo fix_commit.sh en `hostname`
git status
git add .
git status
git commit -m "update en AUS des"
git push origin master
echo "***"
echo "**"
echo "*"
