# !/bin/bash
#
#
dt=`date +20%y%m%d`
ti=`date +%H%M%S`
hs=`hostname`
writein="xrdp_$hs-$dt-$ti.log"
echo
echo chk_xrdp.sh en `hostname`
systemctl status xrdp
#
VAR1=`cat /etc/sysconfig/displaymanager | grep DISPLAYMANAGER_ROOT_LOGIN_REMOTE=\"yes\"`
VAR2=DISPLAYMANAGER_ROOT_LOGIN_REMOTE=\"yes\"
if [ "$VAR1" = "$VAR2" ]; then
    echo "/etc/sysconfig/displaymanager is ok"
else
	cat /etc/sysconfig/displaymanager | grep ROOT_LOGIN
	echo En /etc/sysconfig/displaymanager
	echo DISPLAYMANAGER_ROOT_LOGIN_REMOTE debe ser yes
fi
echo "***"
echo "**"
echo "*"


