#! /bin/bash
# Para SUSE 15 - Actualizado por TM el 5-7-2019
#
dt=`date +20%y%m%d`
ti=`date +%H%M%d`
hs=`hostname`
writein="clamav_$hs-$dt-$ti.log"
echo
echo chk_clamav.sh en `hostname`
clamscan -V
zypper info clamav | grep Status
echo
echo Verifica procesos 
ps -ef | grep clam
systemctl status clamd
echo
echo Verifica crontab
crontab -l
echo
echo Verifica que sea puerto 44410
netstat -napt | grep clamd
echo "***"
echo "**"
echo "*"
