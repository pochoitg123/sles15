# !/bin/bash
#
# "SLES Memory Tuning and Optimization"
# "SLES Disk I/O & Storage Tuning Optimization"
#
dt=`date +20%y%m%d`
ti=`date +%H%M%d`
hs=`hostname`
writein="fix_suseguid01.txt"
function conparam1 {
	paramv=`sysctl -a | grep -w $1 | awk '{print $3}'`
	if [ $paramv -ge $2 ]
	then
		echo $1 "=" $paramv ">=" $2
	else
		echo $1 "=" $2
		echo $1 "=" $2 >> $writein
	fi
	echo
}
#
function conparam2 {
	paramv1=`sysctl -a | grep $1 | awk '{print $3}'`
	paramv2=`sysctl -a | grep $1 | awk '{print $4}'`
	if [ $paramv1 -ge $2 ]
	then
		if [ $paramv2 -ge $3 ]
		then
			echo $1 "=" $paramv1 ">=" $2 $paramv2 ">=" $3
		else
			echo $1 "=" $paramv1 $3   
			echo $1 "=" $paramv1 $3 >> $writein
		fi
	else
		if [ $paramv2 -ge $3 ]
                then         
                        echo $1 "=" $2 $paramv2 
                        echo $1 "=" $2 $paramv2 >> f$writein
                else
                        echo $1 "=" $2 $3  
                        echo $1 "=" $2 $3 >> f$writein 
                fi
	fi
	echo
}
#
function conparam3 {
	paramv1=`sysctl -a | grep $1 | awk '{print $3}'`
	paramv2=`sysctl -a | grep $1 | awk '{print $4}'`
	paramv3=`sysctl -a | grep $1 | awk '{print $5}'`
	if [ $paramv1 -ge $2 ]
	then
		if [ $paramv2 -ge $3 ]
		then
			if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $paramv1 ">=" $2 $paramv2 ">=" $3 $paramv3 ">=" $4
			else
				echo $1 "=" $paramv1 $paramv2 $4
				echo $1 "=" $paramv1 $paramv2 $4 >> $writein
			fi
		else
			if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $paramv1 $3 $paramv3
				echo $1 "=" $paramv1 $3 $paramv3 >> $writein
			else
				echo $1 "=" $paramv1 $3 $4
				echo $1 "=" $paramv1 $3 $4 >> $writein
			fi  
		fi
	else
		if [ $paramv2 -ge $3 ]
        then  
        	if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $2 $paramv2 $paramv3
				echo $1 "=" $2 $paramv2 $paramv3 >> $writein
			else
				echo $1 "=" $2 $paramv2 $4
				echo $1 "=" $2 $paramv2 $4 >> $writein
			fi         
        else
        	if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $2 $3 $paramv3
				echo $1 "=" $2 $3 $paramv3 >> $writein
			else
				echo $1 "=" $2 $3 $4
				echo $1 "=" $2 $3 $4 >> $writein
			fi  
        fi
	fi
	echo
}
#
function confile1 {
	FILE1="/etc/init.d/boot.local"
	filev=`cat $1`
	if [ $filev -ge $2 ]
	then
		echo $1 "=" $filev ">=" $2
	else
		echo $1 "=" $2
		var1=$(grep "fix_suseguid01" $FILE1)
		if [ -z "$var1" ]
		then
			cp $FILE1 $FILE1-$dt-$ti
			echo "#" >> $FILE1
			echo "# fix_suseguid01" $dt $ti >> $FILE1
			echo "echo" $2 ">" $1 >> $FILE1
			echo "# fix_suseguid01" >> $FILE1
			echo "#" >> $FILE1
		else
			echo $1 "ya existe en $FILE1"
		fi
	fi
	echo
}
#
echo "# " > $writein
echo "# fix_suseguid01" $dt $ti >> $writein
echo
echo "SLES Memory Tuning and Optimization"
paramn="vm.nr_hugepages"
parame=128
conparam1 $paramn $parame
#
paramn="vm.swappiness"
parame=25
conparam1 $paramn $parame
#
paramn="vm.vfs_cache_pressure"
parame=50
conparam1 $paramn $parame
#
echo Kernel Samepage Merging = 1
paramn="/sys/kernel/mm/ksm/run"
parame=1
confile1 $paramn $parame
#
echo Memory Overcommit = 0 Kernel checks before grants memory
echo Memory Overcommit = 1 Kernel asumes that has memory and grants memory
echo Memory Overcommit = 2 Kernel overcommit - deny memory if it does not have
paramn="vm.overcommit_memory"
parame=0
conparam1 $paramn $parame
#
echo vm.overcommit_ratio = 50 allocate 50% more than RAM+SWAP
paramn="vm.overcommit_ratio"
parame=20
conparam1 $paramn $parame  
#
echo Free mechanism to drop used memory when swapping. It would be desirable to run “sync” command first before freeing up pagecache , dentries and inodes”
echo “To free pagecache:                                  1”
echo “To free dentries and inodes:                        2”
echo “To free pagecache, dentries and inodes:             3”
paramn="vm.drop_caches"
parame=1
conparam1 $paramn $parame
#
echo "SLES Disk I/O & Storage Tuning Optimization"
paramn="vm.dirty_ratio"
parame=10
conparam1 $paramn $parame
#
paramn="vm.dirty_background_ratio"
parame=5
conparam1 $paramn $parame
#
echo "# fix_suseguid01" >> $writein
echo "#" >> $writein
var1=$(grep 'fix_suseguid01' /etc/sysctl.conf)
if [ -z "$var1" ]
then
   cat $writein >> /etc/sysctl.conf
fi
echo "***"
echo "**"
echo "*"

