#! /bin/bash
#
# 
dt=`date +20%y%m%d`
ti=`date +%H%M%S`
hs=`hostname`
writein="accton_$hs-$dt-$ti.log"
echo
echo chk_accton.sh en `hostname`
ls -al  /var/log/account
ls -al  /var/log/account/pacct
zypper info acct | grep Status
echo "***"
echo "**"
echo "*"
