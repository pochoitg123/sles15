# !/bin/bash
#
# SAP suseguid02 Params
#
echo
echo "SLES11/12 Network Tuning & Optimization"
echo
dt=`date +20%y%m%d`
ti=`date +%H%M%d`
hs=`hostname`
writein="fix_suseguid02.txt"
function conparam1 {
	paramv=`sysctl -a | grep $1 | awk '{print $3}'`
	if [ $paramv -ge $2 ]
	then
		echo $1 "=" $paramv ">=" $2
	else
		echo $1 "=" $2
		echo $1 "=" $2 >> $writein
	fi
	echo
}
#
function conparam2 {
	paramv1=`sysctl -a | grep $1 | awk '{print $3}'`
	paramv2=`sysctl -a | grep $1 | awk '{print $4}'`
	if [ $paramv1 -ge $2 ]
	then
		if [ $paramv2 -ge $3 ]
		then
			echo $1 "=" $paramv1 ">=" $2 $paramv2 ">=" $3
		else
			echo $1 "=" $paramv1 $3   
			echo $1 "=" $paramv1 $3 >> $writein
		fi
	else
		if [ $paramv2 -ge $3 ]
                then         
                        echo $1 "=" $2 $paramv2 
                        echo $1 "=" $2 $paramv2 >> f$writein
                else
                        echo $1 "=" $2 $3  
                        echo $1 "=" $2 $3 >> f$writein 
                fi
	fi
	echo
}
#
function conparam3 {
	paramv1=`sysctl -a | grep $1 | awk '{print $3}'`
	paramv2=`sysctl -a | grep $1 | awk '{print $4}'`
	paramv3=`sysctl -a | grep $1 | awk '{print $5}'`
	if [ $paramv1 -ge $2 ]
	then
		if [ $paramv2 -ge $3 ]
		then
			if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $paramv1 ">=" $2 $paramv2 ">=" $3 $paramv3 ">=" $4
			else
				echo $1 "=" $paramv1 $paramv2 $4
				echo $1 "=" $paramv1 $paramv2 $4 >> $writein
			fi
		else
			if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $paramv1 $3 $paramv3
				echo $1 "=" $paramv1 $3 $paramv3 >> $writein
			else
				echo $1 "=" $paramv1 $3 $4
				echo $1 "=" $paramv1 $3 $4 >> $writein
			fi  
		fi
	else
		if [ $paramv2 -ge $3 ]
        then  
        	if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $2 $paramv2 $paramv3
				echo $1 "=" $2 $paramv2 $paramv3 >> $writein
			else
				echo $1 "=" $2 $paramv2 $4
				echo $1 "=" $2 $paramv2 $4 >> $writein
			fi         
        else
        	if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $2 $3 $paramv3
				echo $1 "=" $2 $3 $paramv3 >> $writein
			else
				echo $1 "=" $2 $3 $4
				echo $1 "=" $2 $3 $4 >> $writein
			fi  
        fi
	fi
	echo
}
#
echo
echo Fix suseguid02 en $hs $dt
echo
echo "# " > $writein
echo "# fix_suseguid02" $dt $ti >> $writein
# 
paramn="net.core.rmem_max"
parame=12582912
conparam1 $paramn $parame
#
paramn="net.core.wmem_max"
parame=12582912
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_rmem"
parame1=4096
parame2=87380
parame3=9437184
conparam3 $paramn $parame1 $parame2 $parame3
#
paramn="net.ipv4.tcp_wmem"
parame1=4096
parame2=87380
parame3=9437184
conparam3 $paramn $parame1 $parame2 $parame3
#
paramn="net.core.netdev_max_backlog"
parame=9000
conparam1 $paramn $parame
#
paramn="net.core.somaxconn"
parame=512
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_sack"
parame=0
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_dsack"
parame=0
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_fack"
parame=0
conparam1 $paramn $parame
#
paramn="net.ipv4.ipfrag_high_thresh"
parame=544288
conparam1 $paramn $parame
#
paramn="net.ipv4.ipfrag_low_thresh"
parame=393216
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_max_syn_backlog"
parame=393216
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_synack_retries"
parame=3
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_retries2"
parame=6
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_keepalive_time"
parame=1000
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_keepalive_probes"
parame=4
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_keepalive_intvl"
parame=20
conparam1 $paramn $parame
#
#paramn="net.ipv4.tcp_tw_recycle"
#parame=1
#conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_tw_reuse"
parame=1
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_fin_timeout"
parame=30
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_mtu_probing"
parame=1
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_syncookies"
parame=1
conparam1 $paramn $parame
#
paramn="net.ipv4.conf.all.accept_source_route"
parame=0
conparam1 $paramn $parame
#
paramn="net.ipv4.conf.all.accept_redirects"
parame=0
conparam1 $paramn $parame
#
paramn="net.ipv4.conf.all.rp_filter"
parame=1
conparam1 $paramn $parame
#
#paramn="net.ipv4.icmp_echo_ignore_all"
#parame=1
#conparam1 $paramn $parame
#
#paramn="net.ipv4.icmp_echo_ignore_broadcasts"
#parame=1
#conparam1 $paramn $parame
#
paramn="net.ipv4.icmp_ignore_bogus_error_responses"
parame=1
conparam1 $paramn $parame
#
paramn="net.ipv4.conf.all.log_martians"
parame=1
conparam1 $paramn $parame
#
paramn="kernel.randomize_va_space"
parame=2
conparam1 $paramn $parame
#
paramn="kernel.kptr_restrict"
parame=1
conparam1 $paramn $parame
#
paramn="fs.protected_hardlinks"
parame=1
conparam1 $paramn $parame
#
paramn="fs.protected_symlinks"
parame=1
conparam1 $paramn $parame
#
echo "# fix_suseguid02" >> $writein
echo "#" >> $writein
var1=$(grep 'fix_suseguid02' /etc/sysctl.conf)
if [ -z "$var1" ]
then
   cat $writein >> /etc/sysctl.conf
fi
echo "***"
echo "**"
echo "*"

