#! /bin/bash
#
#
dt=`date +20%y%m%d`
ti=`date +%H%M`
hs=`hostname`
echo
echo chk_sysctlresp.sh en `hostname`
echo chk_sysctlresp.sh en `hostname` > /root/log/sysctl_$hs-$dt-$ti.log
sysctl -a >> /root/log/sysctl_$hs-$dt-$ti.log
echo "***"
echo "**"
echo "*"

