#!/bin/bash
# Actualizado TM 15-jul-2020
#
dt=`date +20%y%m%d`
ti=`date +%H%M%S`
hs=`hostname`
writein="1275776_$hs-$dt-$ti.log"
#
writefu="fix_1275776.txt"
echo "#" > $writefu
echo "# fix_1275776" $dt $ti >> $writefu

function conparam1 {
	paramv=`sysctl -a | grep $1 | awk '{print $3}'`
	if [ $paramv -ge $2 ]
	then
		echo $1 "=" $paramv ">=" $2
	else
		echo $1 "=" $2
		echo $1 "=" $2 >> $writefu
	fi
	echo
}
#
#
#
echo "1275776 - Linux Preparing Sles for SAP Environments"
zypper install -y sapconf
zypper install -y saptune
echo "saptune daemon enable/start"
saptune daemon enable
saptune daemon start
echo "saptune note list"
saptune note list
echo
echo "saptune daemon status"
saptune daemon status
echo "saptune solution list"
saptune solution list
echo
#
FILE=/etc/sysctl.conf
paramn="vm.max_map_count"
parame=1234567890
conparam1 $paramn $parame
VAR1=$(grep 'fix_1275776' $FILE)
if [ -z "$VAR1" ]; then
   cp $FILE $FILE-$dt-$ti
   cat $writefu >> $FILE
   echo "#" >> $FILE
fi
rm $writefu
#
FILE=/etc/init.d/boot.local
touch $FILE 
chmod +x $FILE
VAR1=$(grep 'bash' $FILE)
if [ -z "$VAR1" ]; then
   cat /root/15sles/boot_local.sh > $FILE
   mkdir /root/log
fi
echo "#" >> $writefu
echo "# fix_12775776" $dt $ti >> $writefu
echo "mount -o remount, size=32G /dev/shm" >> $writefu
echo "# fix_12775776" >> $writefu
echo "#" >> $writefu
VAR1=$(grep 'fix_12775776' $FILE)
if [ -z "$VAR1" ]; then
   cp $FILE $FILE-$dt-$ti
   cat $writefu >> $FILE
   echo "resultado de " $FILE
   cat $FILE
fi
rm $writefu
echo "***"
echo "**"
echo "*"

