#! /bin/bash
#
dt=`date +20%y%m%d`
ti=`date +%H%M%d`
hs=`hostname`
echo
echo chk_dbhanafs.sh en `hostname`
echo
echo Valores de "scheduler" para:
df -h | grep File
df -h | grep "/dev/sd" | sort | grep hana
echo "#! /bin/bash" > chk_hanafs0_tmp.sh
df | grep hana | sort | awk '{gsub("1","",$1);gsub("/dev/","",$1);printf "%s%s%s\n", "cat /sys/block/",$1,"/queue/scheduler"}' >> chk_hanafs0_tmp.sh
chmod +x chk_hanafs0_tmp.sh
./chk_hanafs0_tmp.sh
rm chk_hanafs0_tmp.sh
#
echo Valores de "read_ahead_kb" para:
df -h | grep File
df -h | grep "/dev/sd" | sort | grep hana
echo "#! /bin/bash" > chk_hanafs1_tmp.sh
df | grep hana | sort | awk '{gsub("1","",$1);gsub("/dev/","",$1);printf "%s%s%s\n", "cat /sys/block/",$1,"/queue/read_ahead_kb"}' >> chk_hanafs1_tmp.sh
chmod +x chk_hanafs1_tmp.sh
./chk_hanafs1_tmp.sh
rm chk_hanafs1_tmp.sh
#
echo Valores de "nr_requests" para:
df -h | grep File
df -h | grep "/dev/sd" | sort | grep hana
echo "#! /bin/bash" > chk_hanafs2_tmp.sh
df | grep hana | sort | awk '{gsub("1","",$1);gsub("/dev/","",$1);printf "%s%s%s\n", "cat /sys/block/",$1,"/queue/nr_requests"}' >> chk_hanafs2_tmp.sh
chmod +x chk_hanafs2_tmp.sh
./chk_hanafs2_tmp.sh
rm chk_hanafs2_tmp.sh
echo "***"
echo "**"
echo "*"

