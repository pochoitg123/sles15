#!/bin/bash
# Actualizado TM 15-jul-2020
#
dt=`date +20%y%m%d`
ti=`date +%H%M%S`
hs=`hostname`
writein="xrdp_$hs-$dt-$ti.log"
echo
echo chk_xrdp.sh en `hostname`
zypper install -y xrdp
systemctl enable xrdp
systemctl start xrdp
systemctl status xrdp
#
#
VAR1=`cat /etc/sysconfig/displaymanager | grep DISPLAYMANAGER_ROOT_LOGIN_REMOTE=\"yes\"`
VAR2=DISPLAYMANAGER_ROOT_LOGIN_REMOTE=\"yes\"
if [ "$VAR1" = "$VAR2" ]; then
    echo "/etc/sysconfig/displaymanager is ok"
else
	cp /etc/sysconfig/displaymanager /etc/sysconfig/displaymanager.$dt$ti
	echo "changing /etc/sysconfig/displaymanager"
	cat /etc/sysconfig/displaymanager | grep DISPLAYMANAGER_ROOT_LOGIN_REMOTE
	sed -i 's/\(DISPLAYMANAGER_ROOT_LOGIN_REMOTE=\"no\"\)/DISPLAYMANAGER_ROOT_LOGIN_REMOTE=\"yes\"/g' /etc/sysconfig/displaymanager
	cat /etc/sysconfig/displaymanager | grep DISPLAYMANAGER_ROOT_LOGIN_REMOTE
fi
echo "***"
echo "**"
echo "*"