#!/bin/bash
# Actualizado TM 15-jul-2020
#
dt=`date +20%y%m%d`
ti=`date +%H%M%S`
hs=`hostname`
writein="2578899_$hs-$dt-$ti.log"
#
echo "2578899 - SUSE Linux Enterprise Server 15 Installation Note "
zypper install -y libopenssl1_0_0
# ONLY Scaleout systems
#zypper install libssh2_1
#
writefu=fix_2578899.txt
echo "#" > $writefu
echo "# fix_2578899" $dt $ti >> $writefu
echo "[block]" >> $writefu
echo "IO_SCHEDULER=none" >> $writefu
echo "# fix_2578899" >> $writefu
echo "#" >> $writefu
#
FILE=/etc/saptune/override/2578899
touch $FILE
cp $FILE $FILE-$dt-$ti
cat $writefu >> $FILE
echo "resultado de " $FILE
cat $FILE
rm $writefu
echo
echo "sysstat - monitoring data"
zypper install -y sysstat
systemctl enable sysstat
systemctl start sysstat
echo
echo "UUID daemon"
zypper install -y uuidd
systemctl start uuidd.socket
systemctl status uuidd.socket
echo
echo "*** revisar los ultimos puntos en la nota sap"
echo "***"
echo "**"
echo "*"
