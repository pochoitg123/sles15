# !/bin/bash
#
# SLES11/12 Network Tuning & Optimization addon 10G
#
dt=`date +20%y%m%d`
ti=`date +%H%M%d`
hs=`hostname`
writein="fix_eth10G.txt"
function conparam1 {
	paramv=`sysctl -a | grep -w $1 | awk '{print $3}'`
	if [ $paramv -ge $2 ]
	then
		echo $1 "=" $paramv ">=" $2
	else
		echo $1 "=" $2
		echo $1 "=" $2 >> $writein
	fi
	echo
}
#
function conparam2 {
	paramv1=`sysctl -a | grep $1 | awk '{print $3}'`
	paramv2=`sysctl -a | grep $1 | awk '{print $4}'`
	if [ $paramv1 -ge $2 ]
	then
		if [ $paramv2 -ge $3 ]
		then
			echo $1 "=" $paramv1 ">=" $2 $paramv2 ">=" $3
		else
			echo $1 "=" $paramv1 $3   
			echo $1 "=" $paramv1 $3 >> $writein
		fi
	else
		if [ $paramv2 -ge $3 ]
                then         
                        echo $1 "=" $2 $paramv2 
                        echo $1 "=" $2 $paramv2 >> f$writein
                else
                        echo $1 "=" $2 $3  
                        echo $1 "=" $2 $3 >> f$writein 
                fi
	fi
	echo
}
#
function conparam3 {
	paramv1=`sysctl -a | grep $1 | awk '{print $3}'`
	paramv2=`sysctl -a | grep $1 | awk '{print $4}'`
	paramv3=`sysctl -a | grep $1 | awk '{print $5}'`
	if [ $paramv1 -ge $2 ]
	then
		if [ $paramv2 -ge $3 ]
		then
			if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $paramv1 ">=" $2 $paramv2 ">=" $3 $paramv3 ">=" $4
			else
				echo $1 "=" $paramv1 $paramv2 $4
				echo $1 "=" $paramv1 $paramv2 $4 >> $writein
			fi
		else
			if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $paramv1 $3 $paramv3
				echo $1 "=" $paramv1 $3 $paramv3 >> $writein
			else
				echo $1 "=" $paramv1 $3 $4
				echo $1 "=" $paramv1 $3 $4 >> $writein
			fi  
		fi
	else
		if [ $paramv2 -ge $3 ]
        then  
        	if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $2 $paramv2 $paramv3
				echo $1 "=" $2 $paramv2 $paramv3 >> $writein
			else
				echo $1 "=" $2 $paramv2 $4
				echo $1 "=" $2 $paramv2 $4 >> $writein
			fi         
        else
        	if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $2 $3 $paramv3
				echo $1 "=" $2 $3 $paramv3 >> $writein
			else
				echo $1 "=" $2 $3 $4
				echo $1 "=" $2 $3 $4 >> $writein
			fi  
        fi
	fi
	echo
}
#
function contexto1 {
        paramv=`sysctl -a | grep -w $1 | awk '{print $3}'`
        if [ $paramv = $2 ]
        then
                echo $1 "=" $paramv "=" $2
        else
                echo $1 "=" $2
                echo $1 "=" $2 >> $writein
        fi
        echo
}
#
echo
echo "SLES11/12 Network Tuning & Optimization addon 10G"
echo
echo "# " > $writein
echo "# fix_eth10G" $dt $ti >> $writein
paramn="net.core.rmem_default"
parame=33554432
conparam1 $paramn $parame
#
paramn="net.core.rmem_max"
parame=83886080
conparam1 $paramn $parame
#
paramn="net.core.wmem_default"
parame=33554432
conparam1 $paramn $parame
#
paramn="net.core.wmem_max"
parame=83886080
conparam1 $paramn $parame
#
paramn="net.core.optmem_max"
parame=83886080
conparam1 $paramn $parame
#
echo increase Linux autotuning TCP buffer limit
paramn="net.ipv4.tcp_mem"
parame1=83886080
parame2=83886080
parame3=83886080
conparam3 $paramn $parame1 $parame2 $parame3
#
paramn="net.ipv4.tcp_rmem"
parame1=16777216
parame2=33554432
parame3=83886080
conparam3 $paramn $parame1 $parame2 $parame3
#
paramn="net.ipv4.tcp_wmem"
parame1=16777216
parame2=33554432
parame3=83886080
conparam3 $paramn $parame1 $parame2 $parame3
#
echo increase the length of the processor input queue
paramn="net.core.netdev_max_backlog"
parame=300000
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_max_syn_backlog"
parame=100000
conparam1 $paramn $parame
#
paramn="net.core.somaxconn"
parame=100000
conparam1 $paramn $parame
#
echo recommended default congestion control is htcp en ves de cubic
#paramn="net.ipv4.tcp_congestion_control"
#parame=htcp
#contexto1 $paramn $parame
#
echo recommended for hosts with jumbo frames enabled
paramn="net.ipv4.tcp_mtu_probing"
parame=1
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_no_metrics_save"
parame=1
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_moderate_rcvbuf"
parame=1
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_window_scaling"
parame=1
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_timestamps"
parame=1
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_sack"
parame=1
conparam1 $paramn $parame
#
paramn="net.ipv4.tcp_low_latency"
parame=1
conparam1 $paramn $parame
#
#paramn="net.ipv4.route.flush"
#parame=1
#conparam1 $paramn $parame
#
echo "# fix_eth10G" >> $writein
echo "#" >> $writein
var1=$(grep 'fix_eth10G' /etc/sysctl.conf)
if [ -z "$var1" ]
then
   cat $writein >> /etc/sysctl.conf
fi

var2=$(grep 'fix_eth10G' /etc/init.d/boot.local)
if [ -z "$var2" ]
then
	echo "#" > fix_eth10G_boot_local.txt
	echo "# fix_eth10G" $dt $ti >> fix_eth10G_boot_local.txt
	echo "ifconfig eth0 down" >> fix_eth10G_boot_local.txt
	echo "ifconfig eth0 txqueuelen 10000" >> fix_eth10G_boot_local.txt
	echo "ifconfig eth0 mtu 9000 up" >> fix_eth10G_boot_local.txt
	echo "ethtool -G eth0 rx 4096" >> fix_eth10G_boot_local.txt
	echo "ethtool -G eth0 tx 4096" >> fix_eth10G_boot_local.txt
	echo "ethtool -G eth0 rx-jumbo 4096" >> fix_eth10G_boot_local.txt
	echo "# fix_eth10G" >> fix_eth10G_boot_local.txt
	echo "#" >> fix_eth10G_boot_local.txt
	cat fix_eth10G_boot_local.txt >> /etc/init.d/boot.local
fi
echo
echo "***"
echo "**"
echo "*"

