#! /bin/bash
#
# 
dt=`date +20%y%m%d`
ti=`date +%H%M%S`
hs=`hostname`
writein="appmon_$hs-$dt-$ti.log"
echo
echo fix_appmon.sh en `hostname`
echo "Ingresa la clave de appmon"
useradd -m -g users -G root appmon
passwd appmon
echo "***"
echo "**"
echo "*"
