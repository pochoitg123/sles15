#!/bin/bash
# Actualizado TM 15-jul-2020
#
dt=`date +20%y%m%d`
ti=`date +%H%M%S`
hs=`hostname`
writein="snmpd_$hs-$dt-$ti.log"
echo
echo fix_snmpd.sh en `hostname`
zypper install -y snmp-mibs libsnmp30 net-snmp
systemctl enable snmpd
systemctl start snmpd
systemctl status snmpd
echo "***"
echo "**"
echo "*"