#!/bin/bash
# Actualizado TM 15-jul-2020
#
dt=`date +20%y%m%d`
ti=`date +%H%M%S`
hs=`hostname`
writein="sublime_$hs-$dt-$ti.log"
#
echo
echo "zypper add-repo https://download.sublimetext.com/rpm/stable/x86_64/sublime-text.repo"
zypper addrepo https://download.sublimetext.com/rpm/stable/x86_64/sublime-text.repo
echo
echo "zypper install sublime-text"  
zypper install sublime-text
echo "zypper install firefox"  
zypper install firefox
