#! /bin/bash
#				Actualizado por TM 16-Dic-2020
#
dt=`date +20%y%m%d`
ti=`date +%H%M%d`
hs=`hostname`
echo
#
if [ -z $1 ]
then
	echo Falta host de destino
else
	if [ -z $2 ]
	then
		echo Falta comando a ejecutar en $1
	else
		echo Ejecuta $2 en $1
		ssh root@$1 $2
	fi
fi
echo
echo "***"
echo "**"
echo "*"
