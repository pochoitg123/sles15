# 15sles

Activar github
# zypper addrepo https://download.opensuse.org/repositories/openSUSE:Leap:15.3:Update/standard/openSUSE:Leap:15.3:Update.repo
# zypper refresh
# zypper install git
# git clone https://github.com/aservicesteam/15sles.git

Copiar todos los archivos que no comienzan con chk_ ni con fix_ a /root/bin
Asegurar que /root/bin esta en PATH (echo $PATH)
copiar punto.profile.sh a /root/.profile y asegurar su privilegio +x
En el PATH quedaron los directorios de instalación 
cambiate a al que corresponde, ej 15sles y ejecuta sin ./
Iniciar proceso de instalacion de acuerdo a lo descrito en 0install.txt

Terminado el proceso de instalacion solicitar clon o respaldo ilb
