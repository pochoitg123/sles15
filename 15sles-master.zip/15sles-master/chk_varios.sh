#! /bin/bash
#
# SAP VARIOS Params
#
dt=`date +20%y%m%d`
ti=`date +%H%M%d`
hs=`hostname`
echo
echo chk_varios.sh en `hostname`
echo
function leeparam1 {
	paramv=`sysctl -a | grep -w $1 | awk '{print $3}'`
	echo $1 "=" $paramv
	if [ $paramv -ge $2 ]
	then
		echo $1 "=" $paramv ">=" $2
	else
		echo $1 "=" $2 "***"
	fi
	echo
}
#
function leeparam2 {
	paramv1=`sysctl -a | grep $1 | awk '{print $3}'`
	paramv2=`sysctl -a | grep $1 | awk '{print $4}'`
	echo $1 "=" $paramv1 $paramv2
	if [ $paramv1 -ge $2 ]
	then
		if [ $paramv2 -ge $3 ]
		then
			echo $1 "=" $paramv1 ">=" $2 $paramv2 ">=" $3
		else
			echo $1 "=" $paramv1 $3 "***"  
		fi
	else
		if [ $paramv2 -ge $3 ]
                then         
                        echo $1 "=" $2 $paramv2 "***"
                else
                        echo $1 "=" $2 $3 "***" 
                fi
	fi
	echo
}
#
function leeparam3 {
	paramv1=`sysctl -a | grep $1 | awk '{print $3}'`
	paramv2=`sysctl -a | grep $1 | awk '{print $4}'`
	paramv3=`sysctl -a | grep $1 | awk '{print $5}'`
	echo $1 "=" $paramv1 $paramv2 $paramv3
	if [ $paramv1 -ge $2 ]
	then
		if [ $paramv2 -ge $3 ]
		then
			if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $paramv1 ">=" $2 $paramv2 ">=" $3 $paramv3 ">=" $4
			else
				echo $1 "=" $paramv1 $paramv2 $4 "***"
			fi
		else
			if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $paramv1 $3 $paramv3 "***"
			else
				echo $1 "=" $paramv1 $3 $4 "***"
			fi  
		fi
	else
		if [ $paramv2 -ge $3 ]
        then  
        	if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $2 $paramv2 $paramv3 "***"
			else
				echo $1 "=" $2 $paramv2 $4 "***"
			fi         
        else
        	if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $2 $3 $paramv3 "***"
			else
				echo $1 "=" $2 $3 $4 "***"
			fi  
        fi
	fi
	echo
}
#
function leefile1 {
	filev=`cat $1`
	echo $1 "=" $filev
	if [ $filev -ge $2 ]
	then
		echo $1 "=" $filev ">=" $2
	else
		echo $1 "=" $2 "***"
	fi
	echo
}
#
echo
echo Analisis Varios en $hs $dt
echo
# Kernel
paramn="fs.file-max"
parame=6815744
leeparam1 $paramn $parame
#
paramn="fs.aio-max-nr"
parame=1048576
leeparam1 $paramn $parame
#
paramn="net.ipv4.ip_local_port_range"
parame1=9000
parame2=165500
leeparam2 $paramn $parame1 $parame2 
#
paramn="net.core.rmem_default"
parame=262144
leeparam1 $paramn $parame
#
paramn="net.core.rmem_max"
parame=4194304
leeparam1 $paramn $parame
#
paramn="net.core.wmem_default"
parame=262144
leeparam1 $paramn $parame
#
paramn="net.core.wmem_max"
parame=1048576
leeparam1 $paramn $parame
#
#paramn="vm.pagecache_limit_mb"
#parame=2048
#leeparam1 $paramn $parame
#
paramn="net.core.netdev_max_backlog"
parame=30000
leeparam1 $paramn $parame
#
echo "***"
echo "**"
echo "*"

