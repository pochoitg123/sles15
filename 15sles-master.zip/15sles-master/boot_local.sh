#!/bin/bash
# /etc/init.d/boot.local
#
dt=`date +20%y%m%d`
ti=`date +%H%M%S`
hs=`hostname`
writein="/root/log/boot.local.log"
#
echo "ejecutando boot.local en $hs $dt $ti" >> $writein 
#

