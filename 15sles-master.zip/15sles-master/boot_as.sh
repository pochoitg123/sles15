#!/bin/bash
# /etc/init.d/boot.as
#
dt=`date +20%y%m%d`
ti=`date +%H%M%S`
hs=`hostname`
writein="/root/log/boot.as.log"
#
echo "ejecutando boot.as en $hs $dt $ti" >> $writein 
#

