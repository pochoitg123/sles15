#! /bin/bash
# actualizado por TM 28-feb-2021
#
dt=`date +20%y%m%d`
ti=`date +%H%M%d`
hs=`hostname`
#
writein="srv-$hs-$dt-$ti.log"
#
echo Analisis de $hs $dt $ti > $writein
#SYSTEM
echo " " >> $writein 2>&1
echo SYSTEM Status >> $writein 2>&1
echo fecha `date` >> $writein 2>&1
echo hostname `hostname -f` >> $writein 2>&1
echo uptime `uptime` >> $writein 2>&1
#ntptrace >> $writein 2>&1
#ntpdate -d ntp.shoa.cl >> $writein 2>&1
cat /etc/issue >> $writein 2>&1
uname -a >> $writein 2>&1
#dmidecode -t system >> $writein 2>&1

#RED
echo " " >> $writein 2>&1
echo NETWORK Status >> $writein 2>&1
ethtool eth0 >> $writein 2>&1
route >> $writein 2>&1
ifconfig >> $writein 2>&1

#MEMORIA
echo " " >> $writein 2>&1
echo MEMORY Status >> $writein 2>&1
free -m >> $writein 2>&1
#dmidecode -t memory >> $writein 2>&1

#CPU
echo " " >> $writein 2>&1
echo CPU Status >> $writein 2>&1
lscpu >> $writein 2>&1

#DISCOS
echo " " >> $writein 2>&1
echo DISK Status >> $writein 2>&1
lsscsi >> $writein 2>&1
echo " " >> $writein 2>&1
df -h | grep "Filesystem" >> $writein 2>&1
df -h | grep "/dev/sd" | sort >> $writein 2>&1
echo " " >> $writein 2>&1
lsblk >> $writein 2>&1
echo " " >> $writein 2>&1
cat /etc/fstab >> $writein 2>&1

# SAP & SO
echo " " >> $writein 2>&1
echo "SO Status" >> $writein 2>&1
zypper refresh >> $writein 2>&1
echo " " >> $writein 2>&1
zypper products >> $writein 2>&1
echo " " >> $writein 2>&1
zypper patterns >> $writein 2>&1
varspt=`whereis -b saptune | wc -w`
if [ $varspt -ge 2 ]
then
	echo " " >> $writein 2>&1
	echo "SAP Status" >> $writein 2>&1
	saptune solution list >> $writein 2>&1
	saptune note list >> $writein 2>&1
fi

# Arbol de Directorios Hana / sybase
echo " " >> $writein 2>&1
if [ -d /hana ];
then
  echo HANA >> $writein 2>&1
  ls -R /hana | grep ":$" | sed -e 's/:$//' -e 's/[^-][^\/]*\//--/g' -e 's/^/ /' -e 's/-/|/' >> $writein 2>&1
fi
