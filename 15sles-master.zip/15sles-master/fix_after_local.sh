#! /bin/bash
#
dt=`date +20%y%m%d`
ti=`date +%H%M%d`
hs=`hostname`
writein="fix_after_local.txt"
echo Solo para SLES51
#systemctl enable after.local
#systemctl start after.local
#systemctl status after.local
echo
FILE="/etc/init.d/boot.as"
touch $FILE
echo "Actualizando  /etc/init.d/boot.as"
var1=$(grep fix_after_local /etc/init.d/boot.as)
if [ -z $var1 ]
then
	insserv $FILE
	cat /root/15sles/boot_as.sh > $FILE
	echo "#" > $writein
	echo "# fix_after_local" $dt $ti >> $writein
	echo "sysctl -w vm.pagecache_limit_mb=2048 > /dev/null" >> $writein
	echo "echo 2048 > /proc/sys/vm/pagecache_limit_mb" >> $writein
	echo "echo never > /sys/kernel/mm/transparent_hugepage/enabled" >> $writein
	echo "# fix_after_local" >> $writein
	echo "#" >> $writein
	cat $writein >> $FILE
fi
