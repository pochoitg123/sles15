# !/bin/bash
#
# SLES11/12 Network Tuning & Optimization addon 10G
#
dt=`date +20%y%m%d`
ti=`date +%H%M%S`
hs=`hostname`
echo
echo chk_eth10G.sh en `hostname`
echo
function leeparam1 {
	paramv=`sysctl -a | grep -w $1 | awk '{print $3}'`
	echo $1 "=" $paramv
	if [ $paramv -ge $2 ]
	then
		echo $1 "=" $paramv ">=" $2
	else
		echo $1 "=" $2 "***"
	fi
	echo
}
#
function leeparam2 {
	paramv1=`sysctl -a | grep $1 | awk '{print $3}'`
	paramv2=`sysctl -a | grep $1 | awk '{print $4}'`
	echo $1 "=" $paramv1 $paramv2
	if [ $paramv1 -ge $2 ]
	then
		if [ $paramv2 -ge $3 ]
		then
			echo $1 "=" $paramv1 ">=" $2 $paramv2 ">=" $3
		else
			echo $1 "=" $paramv1 $3 "***"  
		fi
	else
		if [ $paramv2 -ge $3 ]
                then         
                        echo $1 "=" $2 $paramv2 "***"
                else
                        echo $1 "=" $2 $3 "***" 
                fi
	fi
	echo
}
#
function leeparam3 {
	paramv1=`sysctl -a | grep $1 | awk '{print $3}'`
	paramv2=`sysctl -a | grep $1 | awk '{print $4}'`
	paramv3=`sysctl -a | grep $1 | awk '{print $5}'`
	echo $1 "=" $paramv1 $paramv2 $paramv3
	if [ $paramv1 -ge $2 ]
	then
		if [ $paramv2 -ge $3 ]
		then
			if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $paramv1 ">=" $2 $paramv2 ">=" $3 $paramv3 ">=" $4
			else
				echo $1 "=" $paramv1 $paramv2 $4 "***"
			fi
		else
			if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $paramv1 $3 $paramv3 "***"
			else
				echo $1 "=" $paramv1 $3 $4 "***"
			fi  
		fi
	else
		if [ $paramv2 -ge $3 ]
        then  
        	if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $2 $paramv2 $paramv3 "***"
			else
				echo $1 "=" $2 $paramv2 $4 "***"
			fi         
        else
        	if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $2 $3 $paramv3 "***"
			else
				echo $1 "=" $2 $3 $4 "***"
			fi  
        fi
	fi
	echo
}
#
function leetexto1 {
        paramv=`sysctl -a | grep -w $1 | awk '{print $3}'`
        echo $1 "=" $paramv
        if [ $paramv = $2 ]
        then
                echo $1 "=" $paramv "=" $2
        else
                echo $1 "=" $2 "***"
        fi
        echo
}
#
echo
echo Check eth10G en `hostname`	
echo "SLES11/12 Network Tuning & Optimization addon 10G"
echo
var1=$(grep 'fix_eth10G' /etc/sysctl.conf)
if [ -z "$var1" ]
then
   echo Parametros de 10G no aplicados
fi
echo "increase TCP max buffer size settable using setsockopt()"
paramn="net.core.rmem_default"
parame=33554432
leeparam1 $paramn $parame
#
paramn="net.core.rmem_max"
parame=83886080
leeparam1 $paramn $parame
#
paramn="net.core.wmem_default"
parame=33554432
leeparam1 $paramn $parame
#
paramn="net.core.wmem_max"
parame=83886080
leeparam1 $paramn $parame
#
paramn="net.core.optmem_max"
parame=83886080
leeparam1 $paramn $parame
#
echo increase Linux autotuning TCP buffer limit
paramn="net.ipv4.tcp_mem"
parame1=83886080
parame2=83886080
parame3=83886080
leeparam3 $paramn $parame1 $parame2 $parame3
#
paramn="net.ipv4.tcp_rmem"
parame1=16777216
parame2=33554432
parame3=83886080
leeparam3 $paramn $parame1 $parame2 $parame3
#
paramn="net.ipv4.tcp_wmem"
parame1=16777216
parame2=33554432
parame3=83886080
leeparam3 $paramn $parame1 $parame2 $parame3
#
echo increase the length of the processor input queue
paramn="net.core.netdev_max_backlog"
parame=300000
leeparam1 $paramn $parame
#
paramn="net.ipv4.tcp_max_syn_backlog"
parame=100000
leeparam1 $paramn $parame
#
paramn="net.core.somaxconn"
parame=100000
leeparam1 $paramn $parame
#
echo recommended default congestion control is htcp en ves de cubic
paramn="net.ipv4.tcp_congestion_control"
parame=htcp
leetexto1 $paramn $parame
#
echo "recommended for hosts with jumbo frames enabled"
paramn="net.ipv4.tcp_mtu_probing"
parame=1
leeparam1 $paramn $parame
#
paramn="net.ipv4.tcp_no_metrics_save"
parame=1
leeparam1 $paramn $parame
#
paramn="net.ipv4.tcp_moderate_rcvbuf"
parame=1
leeparam1 $paramn $parame
#
paramn="net.ipv4.tcp_window_scaling"
parame=1
leeparam1 $paramn $parame
#
paramn="net.ipv4.tcp_timestamps"
parame=1
leeparam1 $paramn $parame
#
paramn="net.ipv4.tcp_sack"
parame=1
leeparam1 $paramn $parame
#
paramn="net.ipv4.tcp_low_latency"
parame=1
leeparam1 $paramn $parame
#
#paramn="net.ipv4.route.flush"
#parame=1
#leeparam1 $paramn $parame
#
var2=$(grep 'fix_eth10G_boot_local.txt' /etc/init.d/boot.local)
if [ -z "$var2" ]
then
   ifconfig eth0 
   ethtool -g eth0
   dmesg | grep eth0
fi
echo "***"
echo "**"
echo "*"

