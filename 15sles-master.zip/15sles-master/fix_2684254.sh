#!/bin/bash
# Actualizado TM 7-dic-2020
#
dt=`date +20%y%m%d`
ti=`date +%H%M%S`
hs=`hostname`
writein="2684254_$hs-$dt-$ti.log"
#
# 2684254 - SAP HANA DB: Recommended OS settings for SLES 15 / SLES for SAP Applications 15
#
echo "SOLO para servidores con HANA"

zypper install -y libopenssl1_0_0
# ONLY Scaleout systems
#zypper install -y libssh2_1
#

FILE=/etc/systemd/logind.conf.d
    mkdir $FILE
    chmod +rx $FILE
FILE=/etc/systemd/logind.conf.d/sap.conf
touch $FILE
    VAR1=`cat $FILE | grep "fix_2684254" | wc -c`
if [ $VAR1 -eq 0 ]; then
	cp $FILE $FILE.$dt-$ti
	echo "generating " $FILE
	echo "#" >> $FILE
	echo "# fix_2684254" $dt $ti >> $FILE
	echo "[Login]" >> $FILE
	echo "UserTasksMax=infinity" >> $FILE
	echo "# fix_2684254" >> $FILE
	echo "#" >> $FILE
fi
echo
echo "Turn off autoNUMA balancing"
FILE=/etc/default/grub
VAR1=`cat /etc/default/grub | grep GRUB_CMDLINE_LINUX_DEFAULT | grep "numa_balancing=disable" | wc -c`
if [ $VAR1 -eq 0 ]; then
	echo "agregar en GRUB_CMDLINE_LINUX_DEFAULT"
	echo "numa_balancing=disable"
	echo "seleccione para ejecutar vi"
	cp $FILE $FILE.$dt-$ti
	read VAR2
	vi $FILE
	grub2-mkconfig -o /boot/grub2/grub.cfg
fi
echo
echo "Disable transparent hugepages"
FILE=/etc/default/grub
VAR1=`cat /etc/default/grub | grep GRUB_CMDLINE_LINUX_DEFAULT | grep "transparent_hugepage=never" | wc -c`
if [ $VAR1 -eq 0 ]; then
	echo "agregar en GRUB_CMDLINE_LINUX_DEFAULT"
	echo "transparent_hugepage=never"
	echo "seleccione para ejecutar vi"
	cp $FILE $FILE.$dt-$ti
	read VAR2
	vi $FILE
	grub2-mkconfig -o /boot/grub2/grub.cfg
fi
echo
echo "Configure C-States for lower latency in Linux"
FILE=/etc/default/grub
VAR1=`cat /etc/default/grub | grep GRUB_CMDLINE_LINUX_DEFAULT | grep cstate | wc -c`
if [ $VAR1 -eq 0 ]; then
	echo "agregar en GRUB_CMDLINE_LINUX_DEFAULT"
	echo "processor.max_cstate=1 intel_idle.max_cstate=1"
	echo "seleccione para ejecutar vi"
	cp $FILE $FILE.$dt-$ti
	read VAR2
	vi $FILE
	grub2-mkconfig -o /boot/grub2/grub.cfg
fi
echo
echo "Configure cpu governance, Energy Performance, KSM"
FILE=/etc/init.d/boot.local
touch $FILE
cp $FILE $FILE.$dt-$ti
    VAR1=`cat $FILE | grep fix_2684254 | wc -c`
if [ $VAR1 -eq 0 ]; then
	echo "#" >> $FILE
	echo "# fix_2684254" $dt $ti >> $FILE
	echo "# Energy Performance" >> $FILE
	echo "cpupower set -b 0" >> $FILE
	echo "# CPU Frequency" >> $FILE
	echo "cpupower frequency-set -g performance" >> $FILE
#	echo "# Kernel samepage merging" >> $FILE
#	echo "echo 0 > /sys/kernel/mm/ksm/run" >> $FILE
	echo "# fix_2684254" >> $FILE
	echo "#" >> $FILE
fi
echo "***"
echo "**"
echo "*"
