#!/bin/bash
# Actualizado TM 15-jul-2020
#
dt=`date +20%y%m%d`
ti=`date +%H%M%S`
hs=`hostname`
writein="accton_$hs-$dt-$ti.log"
echo
echo chk_accton.sh en `hostname`
zypper install -y acct
mkdir /var/log/account
touch /var/log/account/pacct
accton on
echo "***"
echo "**"
echo "*"
