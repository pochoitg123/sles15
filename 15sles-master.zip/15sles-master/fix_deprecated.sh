# !/bin/bash
#
echo
echo chk_xrdp.sh en `hostname`
echo
# SUSEConnect --url=https://scc.suse.com  -e company@example.com -r YOUR_CODE

# zypper addrepo https://download.opensuse.org/repositories/network:utilities/SLE_15/network:utilities.repo
zypper refresh
zypper install net-tools-deprecated

zypper install nmap
zypper install python
zypper install dconf-editor
