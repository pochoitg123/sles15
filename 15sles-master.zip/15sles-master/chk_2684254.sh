#!/bin/bash
# Actualizado TM 15-jul-2020
#
dt=`date +20%y%m%d`
ti=`date +%H%M%S`
hs=`hostname`
writein="2684254_$hs-$dt-$ti.log"
#
# 2684254 - SAP HANA DB: Recommended OS settings for SLES 15 / SLES for SAP Applications 15
#
echo "SOLO para servidores con HANA"

echo libopenssl1_0_0
zypper se -i libopenssl1_0_0
# ONLY Scaleout systems
#echo libssh2_1
#zypper se -i libssh2_1
#

FILE=/etc/systemd/logind.conf.d/sap.conf
if  [ test -f "$FILE" ]; then
    echo "$FILE existe"
    VAR1=`cat $FILE | grep "fix_2684254" | wc -c`
else
	VAR1=0
fi
if [ $VAR1 -eq 0 ]; then
	echo "Debe generarse " $FILE
else
	echo "Ya existe aplicacion de nota 2684254"
fi
echo
echo "Turn off autoNUMA balancing"
FILE=/etc/default/grub
VAR1=`cat /etc/default/grub | grep GRUB_CMDLINE_LINUX_DEFAULT | grep "numa_balancing=disable" | wc -c`
if [ $VAR1 -eq 0 ]; then
	echo "Se debe agregar en GRUB_CMDLINE_LINUX_DEFAULT"
	echo "numa_balancing=disable"
else
	echo "Ya existe en GRUB_CMDLINE_LINUX_DEFAULT"
	echo "numa_balancing=disable"
	cat /etc/default/grub | grep GRUB_CMDLINE_LINUX_DEFAULT | grep "numa_balancing=disable"
fi
echo
echo "Disable transparent hugepages"
FILE=/etc/default/grub
VAR1=`cat /etc/default/grub | grep GRUB_CMDLINE_LINUX_DEFAULT | grep "transparent_hugepage=never" | wc -c`
if [ $VAR1 -eq 0 ]; then
	echo "Se debe agregar en GRUB_CMDLINE_LINUX_DEFAULT"
	echo "transparent_hugepage=never"
else
	echo "Ya existe en GRUB_CMDLINE_LINUX_DEFAULT"
	echo "transparent_hugepage=never"
	cat /etc/default/grub | grep GRUB_CMDLINE_LINUX_DEFAULT | grep "transparent_hugepage=never"
fi
echo
echo "Configure C-States for lower latency in Linux"
FILE=/etc/default/grub
VAR1=`cat /etc/default/grub | grep GRUB_CMDLINE_LINUX_DEFAULT | grep cstate | wc -c`
if [ $VAR1 -eq 0 ]; then
	echo "Se debe agregar en GRUB_CMDLINE_LINUX_DEFAULT"
	echo "processor.max_cstate=1 intel_idle.max_cstate=1"
else
	echo "Ya existe en GRUB_CMDLINE_LINUX_DEFAULT"
	echo "processor.max_cstate=1 intel_idle.max_cstate=1"
	cat /etc/default/grub | grep GRUB_CMDLINE_LINUX_DEFAULT | grep cstate
fi
echo
echo "Configure cpu governance, Energy Performance, KSM"
FILE=/etc/init.d/boot.local
VAR1=`cat $FILE | grep fix_2684254 | wc -c`
if [ $VAR1 -eq 0 ]; then
	echo "Se deben agregar en $FILE "
	echo "# Energy Performance" 
	echo "cpupower set -b 0"
	echo "# CPU Frequency"
	echo "cpupower frequency-set -g performance" 
	echo "# Kernel samepage merging" 
	echo "echo 0 > /sys/kernel/mm/ksm/run" 
else
	echo "ya existe la aplicacion de fix_2684254 en $FILE"
	cat $FILE
fi
echo "***"
echo "**"
echo "*"
