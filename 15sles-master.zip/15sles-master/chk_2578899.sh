#!/bin/bash
# Actualizado TM 15-jul-2020
#
dt=`date +20%y%m%d`
ti=`date +%H%M%S`
hs=`hostname`
writein="2578899_$hs-$dt-$ti.log"
#
echo "2578899 - SUSE Linux Enterprise Server 15 Installation Note "
echo verificando libopenssl1_0_0
zypper se -i libopenssl1_0_0
# ONLY Scaleout systems
#echo libssh2_1
#zypper se -i libssh2_1
#

FILE=/etc/saptune/override/2578899
VAR1=`grep fix_2578899 $FILE | wc -c`
if [ $VAR1 -eq 0 ]; then
    echo "$FILE debe crearse, la nota no esta aplicada"
else
    echo "$FILE existe"
    cat $FILE
fi
echo
echo "sysstat - monitoring data"
#zypper se -i sysstat
systemctl status sysstat
echo
echo "UUID daemon"
#zypper se -i uuidd
systemctl status uuidd.socket
echo
echo "*** revisar los ultimos puntos en la nota sap"
echo "***"
echo "**"
echo "*"
