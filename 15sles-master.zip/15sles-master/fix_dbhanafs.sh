#! /bin/bash
#
echo "#" > fix_dbhanafs.txt
echo "# fix_dbhanafs" >> fix_dbhanafs.txt
df | grep hana | sort | awk '{gsub("1","",$1);gsub("/dev/","",$1);printf "%s%s%s\n", "echo none > /sys/block/",$1,"/queue/scheduler"}' >> fix_hanafs0_tmp.sh
chmod +x fix_hanafs0_tmp.sh
cat fix_hanafs0_tmp.sh
cat fix_hanafs0_tmp.sh >> fix_dbhanafs.txt
rm fix_hanafs0_tmp.sh
#
df | grep hana | sort | awk '{gsub("1","",$1);gsub("/dev/","",$1);printf "%s%s%s\n", "echo 1024 > /sys/block/",$1,"/queue/read_ahead_kb"}' >> fix_hanafs1_tmp.sh
chmod +x fix_hanafs1_tmp.sh
cat fix_hanafs1_tmp.sh
cat fix_hanafs1_tmp.sh >> fix_dbhanafs.txt
rm fix_hanafs1_tmp.sh
#
df | grep hana | sort | awk '{gsub("1","",$1);gsub("/dev/","",$1);printf "%s%s%s\n", "echo 1024 > /sys/block/",$1,"/queue/nr_requests"}' >> fix_hanafs2_tmp.sh
chmod +x fix_hanafs2_tmp.sh
cat fix_hanafs2_tmp.sh
cat fix_hanafs2_tmp.sh >> fix_dbhanafs.txt
rm fix_hanafs2_tmp.sh
#
echo "# fix_dbhanafs" >> fix_dbhanafs.txt
echo "#" >> fix_dbhanafs.txt
echo 
var1=$(grep 'fix_dbhanafs' /etc/init.d/boot.local)
if [ -z "$var1" ]
then
   cat fix_dbhanafs.txt >> /etc/init.d/boot.local
fi
rm fix_dbhanafs.txt
