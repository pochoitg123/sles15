#! /bin/bash
#				Actualizado por TM 16-Dic-2020
#
dt=`date +20%y%m%d`
ti=`date +%H%M%d`
hs=`hostname`
echo
echo Genera key en `hostname` 
#
ssh-keygen -b 4096 -t rsa
echo
echo "***"
echo "**"
echo "*"
