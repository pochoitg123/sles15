#! /bin/bash
#
#
dt=`date +20%y%m%d`
ti=`date +%H%M%S`
hs=`hostname`
writein="snmpd_$hs-$dt-$ti.log"
echo
echo chk_snmpd.sh en `hostname`
systemctl status snmpd.service
echo "***"
echo "**"
echo "*"
