# !/bin/bash
#
# SLES11/12 Network Tuning & Optimization
#
dt=`date +20%y%m%d`
ti=`date +%H%M%d`
hs=`hostname`
echo
echo chk_suseguid02.sh en `hostname`
echo
function leeparam1 {
	paramv=`sysctl -a | grep -w $1 | awk '{print $3}'`
	echo $1 "=" $paramv
	if [ $paramv -ge $2 ]
	then
		echo $1 "=" $paramv ">=" $2
	else
		echo $1 "=" $2 "***"
	fi
	echo
}
#
function leeparam2 {
	paramv1=`sysctl -a | grep $1 | awk '{print $3}'`
	paramv2=`sysctl -a | grep $1 | awk '{print $4}'`
	echo $1 "=" $paramv1 $paramv2
	if [ $paramv1 -ge $2 ]
	then
		if [ $paramv2 -ge $3 ]
		then
			echo $1 "=" $paramv1 ">=" $2 $paramv2 ">=" $3
		else
			echo $1 "=" $paramv1 $3 "***"  
		fi
	else
		if [ $paramv2 -ge $3 ]
                then         
                        echo $1 "=" $2 $paramv2 "***"
                else
                        echo $1 "=" $2 $3 "***" 
                fi
	fi
	echo
}
#
function leeparam3 {
	paramv1=`sysctl -a | grep $1 | awk '{print $3}'`
	paramv2=`sysctl -a | grep $1 | awk '{print $4}'`
	paramv3=`sysctl -a | grep $1 | awk '{print $5}'`
	echo $1 "=" $paramv1 $paramv2 $paramv3
	if [ $paramv1 -ge $2 ]
	then
		if [ $paramv2 -ge $3 ]
		then
			if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $paramv1 ">=" $2 $paramv2 ">=" $3 $paramv3 ">=" $4
			else
				echo $1 "=" $paramv1 $paramv2 $4 "***"
			fi
		else
			if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $paramv1 $3 $paramv3 "***"
			else
				echo $1 "=" $paramv1 $3 $4 "***"
			fi  
		fi
	else
		if [ $paramv2 -ge $3 ]
        then  
        	if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $2 $paramv2 $paramv3 "***"
			else
				echo $1 "=" $2 $paramv2 $4 "***"
			fi         
        else
        	if [ $paramv3 -ge $4 ]
			then
				echo $1 "=" $2 $3 $paramv3 "***"
			else
				echo $1 "=" $2 $3 $4 "***"
			fi  
        fi
	fi
	echo
}
#
function leefile1 {
	filev=`cat $1`
	echo $1 "=" $filev
	if [ $filev -ge $2 ]
	then
		echo $1 "=" $filev ">=" $2
	else
		echo $1 "=" $2 "***"
	fi
	echo
}
#
echo
echo Check suseguid02 en `hostname`
echo "SLES11/12 Network Tuning & Optimization"
echo SLES Kernel Packet Optimization
#
echo Min value de 12mb 12582912
paramn="net.core.rmem_max"
parame=12582912
leeparam1 $paramn $parame
#
paramn="net.core.wmem_max"
parame=12582912
leeparam1 $paramn $parame
#
echo Accomodate maximum incoming packets to 9000
paramn="net.core.netdev_max_backlog"
parame=9000
leeparam1 $paramn $parame
#
echo "Increase the queue size for incoming connection to 512"
paramn="net.core.somaxconn"
parame=512
leeparam1 $paramn $parame
#
echo "Basic TCP/IP Optimization for SLES"
paramn="net.ipv4.tcp_rmem"
parame1=4096
parame2=87380
parame3=9437184
leeparam3 $paramn $parame1 $parame2 $parame3
#
paramn="net.ipv4.tcp_wmem"
parame1=4096
parame2=87380
parame3=9437184
leeparam3 $paramn $parame1 $parame2 $parame3
#
echo "Disabling TCP SACK, DSACK, FACK must be 0 all"
paramn="net.ipv4.tcp_sack"
parame=0
leeparam1 $paramn $parame
#
paramn="net.ipv4.tcp_dsack"
parame=0
leeparam1 $paramn $parame
#
paramn="net.ipv4.tcp_fack"
parame=0
leeparam1 $paramn $parame
#
echo "IP Fragmentation max mem to use"
paramn="net.ipv4.ipfrag_high_thresh"
parame=544288
leeparam1 $paramn $parame
#

echo "ipfrag_low_thresh when its reached, retransmition of packets stops."
paramn="net.ipv4.ipfrag_low_thresh"
parame=393216
leeparam1 $paramn $parame
#
echo "TCP SYN QUEUE"
paramn="net.ipv4.tcp_max_syn_backlog"
parame=8192
leeparam1 $paramn $parame
#
echo "TCP Retries tcp_synack_retries must be 3 if network speed is greather than 1Gbit per second"
paramn="net.ipv4.tcp_synack_retries"
parame=3
leeparam1 $paramn $parame
#
echo "tcp_retries2 must be 6"
paramn="net.ipv4.tcp_retries2"
parame=6
leeparam1 $paramn $parame
#
echo "TCP Keep Alive Time tcp_keepalive_time 1000 seconds is enough to" 
paramn="net.ipv4.tcp_keepalive_time"
parame=1000
leeparam1 $paramn $parame
#
echo "tcp_keepalive_probe 4 allows terminate dead connections faster"
paramn="net.ipv4.tcp_keepalive_probes"
parame=4
leeparam1 $paramn $parame
#
echo "TCP Keep Alive Probe tcp_keepalive_intvl is 20 seconds is enough for the server to see failed connections"
paramn="net.ipv4.tcp_keepalive_intvl"
parame=20
leeparam1 $paramn $parame
#
#echo "TCP_TW_RECYCLE enabled to 1"
#paramn="net.ipv4.tcp_tw_recycle"
#parame=1
#leeparam1 $paramn $parame
#
echo "TCP_TW_REUSE enabled to 1"
paramn="net.ipv4.tcp_tw_reuse"
parame=1
leeparam1 $paramn $parame
#
echo "TCP_FIN_TIMEOUT reduced to 30"
paramn="net.ipv4.tcp_fin_timeout"
parame=30
leeparam1 $paramn $parame
#
echo "Jumbo Frames /etc/sysconfig/network/ifcfg-eth0 parameter to MTU=’9000′"
cat /etc/sysconfig/network/ifcfg-eth0 | grep MTU
echo
#
echo "tcp_mtu_probing enabled to 1"
paramn="net.ipv4.tcp_mtu_probing"
parame=1
leeparam1 $paramn $parame
#
echo "SLES Network/Kernel Security"
echo
echo "1) Enable TCP SYN Cookie Protection = 1"
paramn="net.ipv4.tcp_syncookies"
parame=1
leeparam1 $paramn $parame
#
echo "2) Disable IP Source Routing = 0"
paramn="net.ipv4.conf.all.accept_source_route"
parame=0
leeparam1 $paramn $parame
#
echo "3) Disable ICMP Redirect Acceptance = 0"
paramn="net.ipv4.conf.all.accept_redirects"
parame=0
leeparam1 $paramn $parame
#
echo "4) Enable IP Spoofing Protection = 1"
paramn="net.ipv4.conf.all.rp_filter"
parame=1
leeparam1 $paramn $parame
#
echo "5) Enable Ignoring to ICMP Requests = 1 ***NO"
paramn="net.ipv4.icmp_echo_ignore_all"
parame=1
leeparam1 $paramn $parame
#
echo "6) Enable Ignoring Broadcasts Request = 1 ***NO"
paramn="net.ipv4.icmp_echo_ignore_broadcasts"
parame=1
leeparam1 $paramn $parame
#
echo "7) Enable Bad Error Message = 1"
paramn="net.ipv4.icmp_ignore_bogus_error_responses"
parame=1
leeparam1 $paramn $parame
#
echo "8) Enable Logging of Spoofed Packets, Source Routed Packets, Redirect Packets = 1"
paramn="net.ipv4.conf.all.log_martians"
parame=1
leeparam1 $paramn $parame
#
echo "9) Virtual Address Space Randomization = 2"
paramn="kernel.randomize_va_space"
parame=2
leeparam1 $paramn $parame
#
echo "10) Enable kptr_restrict = 1"
paramn="kernel.kptr_restrict"
parame=1
leeparam1 $paramn $parame
#
echo "11) File System Hardening = 1 y 1"
paramn="fs.protected_hardlinks"
parame=1
leeparam1 $paramn $parame
#
paramn="fs.protected_symlinks"
parame=1
leeparam1 $paramn $parame
#
echo "***"
echo "**"
echo "*"




