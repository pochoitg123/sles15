#! /bin/bash
# Actualizado por TM 1-Feb-2021
#
dt=`date +20%y%m%d`
ti=`date +%H%M%d`
hs=`hostname`
echo
echo Configura Netbackup en `hostname` 
#
var1=$(grep nb5240 /etc/hosts)
if [ -z $var1 ]
then
   echo "#" >> /etc/hosts
   echo "# Claro Netbackup" >> /etc/hosts
   echo "10.94.76.205	dcl-nb5240-m" >> /etc/hosts
   echo "#" >> /etc/hosts
fi
echo
echo Para configurar la interfaz de la red de respaldos usar
echo IP entregada por equipo Claro DCL 
echo Mascara 255.255.252.0
echo hostname dejar en blanco
echo Software de instalación obtener de NetBackup_*_CLIENTS2.tar
echo https://1drv.ms/u/s!Ato-hVCP75s3i_04mpSgQm7ocys7GQ?e=GjN351
echo Si pide token: LGUKCXXABWBVJRNA
echo "***"
echo "**"
echo "*"
